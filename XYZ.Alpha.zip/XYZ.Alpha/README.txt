*DISCLAIMER!*
this coding language is still in it's DEEP alpha; so any reports or bugs you may have with the code, please report back to pezra56@gmail.com.

*HOW TO USE*
input your code into the "myprogram.xyz" file, open the "main.py", then run the code.
Don't worry, I put a basic function in the "myprogram.xyz" file, and the rest of the features are in the GitHub.