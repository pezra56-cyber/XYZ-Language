from __future__ import annotations
import re
import tkinter as tk
from tkinter import Tk, Label, Button
import random
import time
import sys
import os
from typing import List, Dict, Optional, Callable

def pr(*args):
    print(*args)

class AutoNamespace(dict):
    def __init__(self):
        super().__init__()
        self._bindings: Dict[str, List[tk.Label]] = {}

    def bind_label(self, var_name: str, label_widget: tk.Label):
        self._bindings.setdefault(var_name, []).append(label_widget)

    def __setitem__(self, key, value):
        super().__setitem__(key, value)
        if key in self._bindings:
            for lbl in self._bindings[key]:
                try:
                    lbl.config(text=str(value))
                except Exception:
                    pass

REPLACEMENTS = [
    (re.compile(r'\bnull\b'), 'None'),
    (re.compile(r'\bdiff\b'), 'or'),
    (re.compile(r'\bsame\b'), 'and'),
    (re.compile(r'\bnott\b'), 'not'),
    (re.compile(r'\btype:\b'), 'class'),
    (re.compile(r'\bques else if:\b'), 'elif'),
    (re.compile(r'\bfinal\b'), 'finally'),
    (re.compile(r'\bpath:\b'), 'from'),
    (re.compile(r'\bpause from\b'), 'yield from'),
    (re.compile(r'\bpause\b'), 'yield'),
    (re.compile(r'\b__imp__\b'), '__import__'),
]

_single_eq_re = re.compile(r'(?<![=!<>:])=(?!=)')

def _normalize_condition(cond: str) -> str:
    cond = cond.rstrip()
    if cond.endswith(':'):
        cond = cond[:-1].rstrip()
    return _single_eq_re.sub('==', cond)

def _wrap_token(token: str) -> str:
    t = token.strip()
    if not t:
        return t
    if (t.startswith('"') and t.endswith('"')) or (t.startswith("'") and t.endswith("'")):
        return t
    if t.replace('.', '', 1).isdigit():
        return t
    if t in ("True", "False", "None"):
        return t
    if "(" in t and t.endswith(")"):
        return t
    if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', t):
        return f'"{t}"'
    return f'"{t}"'

def _translate_pr(line: str) -> str:
    indent = line[:len(line) - len(line.lstrip())]
    content = line.strip()[len("pr:"):].strip()
    if content.startswith("(") and content.endswith(")"):
        return indent + "pr" + content
    parts = [p.strip() for p in re.split(r',(?![^"\']*["\'])', content)]
    wrapped = [_wrap_token(p) for p in parts if p != ""]
    return indent + f"pr({', '.join(wrapped)})"

def _translate_imp(line: str) -> str:
    indent = line[:len(line) - len(line.lstrip())]
    module_part = line.strip()[len("imp:"):].strip()
    if module_part.startswith('"') or module_part.startswith("'"):
        mod = module_part[1:-1]
        if mod.lower().endswith(".xyz"):
            return indent + f"run({repr(mod)})"
        return indent + f"import {mod}"
    return indent + f"import {module_part}"

def _translate_func(line: str) -> str:
    return line.replace("func ", "def ", 1)

def _translate_ques(line: str) -> str:
    indent = line[:len(line) - len(line.lstrip())]
    stripped = line.strip()
    if stripped.startswith("ques else if "):
        cond = _normalize_condition(stripped[len("ques else if "):])
        return indent + f"elif {cond}:"
    if stripped.startswith("ques if "):
        cond = _normalize_condition(stripped[len("ques if "):])
        return indent + f"if {cond}:"
    if stripped.startswith("ques else"):
        return indent + "else:"
    return line

def _translate_dur(line: str) -> str:
    indent = line[:len(line) - len(line.lstrip())]
    stripped = line.strip()
    if stripped == "dur:":
        return indent + "while True:"
    if stripped.startswith("dur "):
        cond = _normalize_condition(stripped[len("dur "):])
        return indent + f"while {cond}:"
    return line

FUNCTIONS: Dict[str, List[str]] = {}

def define_function(name: str, body: List[str]):
    FUNCTIONS[name] = body

def call_function(name: str, ns: dict):
    if name in FUNCTIONS:
        for ln in FUNCTIONS[name]:
            if ln.strip() == "":
                continue
            _execute_line(ln, ns)
    else:
        maybe = ns.get(name)
        if callable(maybe):
            maybe()
        else:
            try:
                eval(f"{name}()", ns)
            except Exception as e:
                print(f"[XYZ] Function '{name}' failed: {e}")

class GUIBuilder:
    def __init__(self, ns: AutoNamespace):
        self.root: Optional[tk.Tk] = None
        self.gui_lines: List[str] = []
        self.ns = ns
        self.has_mainloop = False

    def add_line(self, line: str):
        s = line.strip()
        if s == "win_mainloop":
            self.has_mainloop = True
        else:
            self.gui_lines.append(line)

    def execute(self, ns: dict):
        if not self.root:
            self.root = tk.Tk()
            self.root.geometry("400x300")
            self.root.title("XYZ Window")
        for l in self.gui_lines:
            s = l.strip()
            if s.startswith("label:"):
                args = [a.strip() for a in s[len("label:"):].split(",")]
                if len(args) != 5:
                    continue
                text, x, y, w, h = args
                x, y, w, h = int(x), int(y), int(w), int(h)
                lbl_text = ns.get(text, text)
                lbl = Label(self.root, text=str(lbl_text))
                lbl.place(x=x, y=y, width=w, height=h)
                if text in ns:
                    ns.bind_label(text, lbl)
            elif s.startswith("button:"):
                args = [a.strip() for a in s[len("button:"):].split(",")]
                if len(args) < 5:
                    continue
                text, x, y, w, h = args[:5]
                cb_expr = args[5] if len(args) > 5 else None
                x, y, w, h = int(x), int(y), int(w), int(h)
                if cb_expr:
                    cb_name = cb_expr.strip().rstrip("()")
                    cb_fn = ns.get(cb_name)
                    if cb_fn:
                        Button(self.root, text=text, command=lambda fn=cb_fn: fn()).place(x=x, y=y, width=w, height=h)
                    else:
                        Button(self.root, text=text, command=lambda: None).place(x=x, y=y, width=w, height=h)
                else:
                    Button(self.root, text=text, command=lambda: None).place(x=x, y=y, width=w, height=h)
            elif s.startswith("win.edit:"):
                edit_lines = self.gui_lines[self.gui_lines.index(l)+1:]
                for el in edit_lines:
                    if "=" in el:
                        k, v = el.split("=", 1)
                        try:
                            self.root.configure(**{k.strip(): v.strip().strip('"').strip("'")})
                        except Exception:
                            pass
            elif s.startswith("win.pack()"):
                pass
        if self.has_mainloop:
            self.root.mainloop()

def _execute_line(raw_line: str, ns: dict):
    line = raw_line.strip()
    if line.startswith("pr:"):
        exec(_translate_pr(line), ns)
    elif line.startswith("imp:"):
        exec(_translate_imp(line), ns)
    elif line.startswith("func "):
        exec(_translate_func(line), ns)
    elif line.startswith("ques"):
        exec(_translate_ques(line), ns)
    elif line.startswith("dur"):
        exec(_translate_dur(line), ns)
    elif line.startswith("call "):
        call_function(line[len("call "):].rstrip("()"), ns)
    else:
        exec(line, ns)

def run(file_path: str):
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception as e:
        print(f"[XYZ] Cannot open {file_path}: {e}")
        return

    ns = AutoNamespace()
    ns["pr"] = pr
    ns["random"] = random
    ns["time"] = time
    gui = GUIBuilder(ns)
    idx = 0
    while idx < len(lines):
        ln = lines[idx].rstrip("\n")
        stripped = ln.strip()
        if stripped.startswith("wind func:"):
            gui_block = []
            idx += 1
            while idx < len(lines) and (lines[idx].startswith("    ") or lines[idx].strip() == ""):
                gui_block.append(lines[idx][4:])
                idx += 1
            for gline in gui_block:
                gui.add_line(gline)
        elif any(stripped.startswith(p) for p in ["label:", "button:", "win.edit:", "win.pack()", "win_mainloop"]):
            gui.add_line(ln)
            idx += 1
        else:
            _execute_line(ln, ns)
            idx += 1

    for fname in FUNCTIONS.keys():
        ns[fname] = lambda __fname=fname, __ns=ns: call_function(__fname, __ns)

    gui.execute(ns)
